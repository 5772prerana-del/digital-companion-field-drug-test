Build a modern, responsive web application called “DrugTest Companion”, a digital companion for field drug-testing officers.

1. Project Goal

The application should help authorized field officers conduct, record, manage, and verify drug-testing activities in remote or field environments. It should reduce paperwork, improve accuracy, maintain a clear chain of custody, and provide quick access to testing information.

The application is a prototype/demo for a hackathon, so use realistic dummy data and simulated test results. Do not connect to real law-enforcement databases or make real-world enforcement decisions.

2. Target Users

- Field Drug Testing Officers
- Laboratory Personnel
- Supervisors/Admins

3. Main Features

A. Login & Authentication

Create a professional login page with:

- Officer ID / Email
- Password
- Role selection: Officer, Lab Technician, Admin
- Login button
- Forgot password
- Demo login credentials displayed subtly for testing

After login, redirect users to the appropriate dashboard.

B. Officer Dashboard

Create a clean dashboard showing:

- Total tests conducted
- Tests pending
- Samples submitted
- Positive / presumptive-positive results
- Samples requiring laboratory confirmation
- Recent testing activities
- Quick actions:
  - New Test
  - Scan Sample QR
  - View Samples
  - Upload Evidence
  - View Reports

Use cards, icons, charts, and status badges.

C. New Field Test

Create a step-by-step testing workflow:

Step 1 — Case Information

- Case/Reference ID
- Date and time
- Testing location
- Officer ID
- Subject/reference identifier
- Notes

Step 2 — Sample Information

- Sample ID
- Sample type
- Collection date/time
- Collection location
- Container/seal number
- Sample condition

Generate a unique QR/barcode for the sample.

Step 3 — Field Test
Display a simulated field-test interface:

- Test kit ID
- Kit batch number
- Expiry date
- Test start time
- Test completion time
- Target substance/category
- Test result:
  - Negative
  - Presumptive Positive
  - Invalid

Allow the officer to upload a photo of the test strip/device.

Step 4 — Verification
Show a summary of all entered information and allow the officer to:

- Review
- Edit
- Confirm
- Submit

D. Chain of Custody

Create a dedicated Chain of Custody page.

Display a timeline showing:

1. Sample collected
2. Sample sealed
3. Sample registered
4. Sample transferred
5. Sample received by laboratory
6. Laboratory testing
7. Report generated

Each event should contain:

- Date/time
- Person/role
- Location
- Action
- Sample ID
- Digital signature/status

Use a visual timeline with clear status indicators.

E. QR/Barcode Scanner

Create a scanner interface that can simulate scanning a sample QR code.

After scanning, display:

- Sample ID
- Case ID
- Collection date
- Current status
- Custody history
- Test result
- Laboratory status

Include a fallback option to manually enter the sample ID.

F. Evidence Management

Create an evidence page where officers can upload:

- Test strip/device photographs
- Sample/container photographs
- Documents
- Other supporting evidence

Show uploaded files with:

- File name
- Upload date/time
- Sample ID
- Officer
- File type
- Verification status

Use dummy uploads for the prototype.

G. Sample Management

Create a searchable and filterable table containing:

- Sample ID
- Case ID
- Sample type
- Date
- Status
- Field result
- Laboratory status
- Chain-of-custody status

Filters:

- Date
- Status
- Result
- Sample type

Clicking a sample should open a detailed sample profile.

H. Laboratory Module

Create a laboratory dashboard where authorized laboratory personnel can:

- View received samples
- Accept/reject sample receipt
- Update testing status
- Enter simulated laboratory results
- Upload laboratory reports
- Mark confirmation as completed

Possible statuses:

- Awaiting Lab
- Received
- Under Analysis
- Confirmed Negative
- Confirmed Positive
- Invalid / Retest Required

I. Reports

Create a reporting section with:

- Test summary
- Sample history
- Chain-of-custody report
- Laboratory confirmation report

Allow reports to be previewed and provide a Download PDF button using demo data.

J. Notifications

Create a notification center for:

- New sample received
- Chain-of-custody update
- Laboratory result available
- Invalid test
- Retest required
- Missing information

Use notification badges and timestamps.

K. Admin Dashboard

Create an admin dashboard showing:

- Total officers
- Total samples
- Tests completed
- Pending laboratory confirmations
- Invalid tests
- Activity statistics

Include simple charts for:

- Tests over time
- Result distribution
- Sample status
- Laboratory processing time

4. UI/UX Design

Use a professional government/public-safety technology style.

Design requirements:

- Clean modern interface
- Responsive for desktop, tablet, and mobile
- Mobile-first field officer workflow
- Easy-to-read typography
- High contrast
- Accessible buttons
- Clear status badges
- Minimal unnecessary animations
- Professional dashboard cards
- Sidebar navigation on desktop
- Bottom navigation or collapsible menu on mobile

Use a professional blue/white/neutral visual theme.

5. Important Field-Use Features

Because the application is intended for field environments, include:

- Offline-friendly UI
- Local draft saving
- Sync status indicator
- “Saved locally” notification
- Automatic timestamps
- Form validation
- Required-field indicators
- Unique sample IDs
- Audit trail

For the prototype, simulate offline storage using browser localStorage or IndexedDB.

6. Data Security & Integrity

Implement prototype-level security features:

- Role-based access control
- Read-only views for unauthorized users
- Audit logs
- Sample ID validation
- Immutable-looking custody timeline
- Confirmation dialogs before important actions

Clearly label the application as a prototype and use dummy/sample data only.

7. Technology

Use:

- React
- TypeScript
- Tailwind CSS
- Modern component library such as shadcn/ui
- Lucide icons
- Recharts for dashboard charts
- Browser localStorage/IndexedDB for prototype persistence

Keep the architecture modular and clean so that a real backend can be integrated later.

8. Navigation

Create the following sidebar navigation:

Dashboard
New Field Test
Samples
QR Scanner
Chain of Custody
Evidence
Laboratory
Reports
Notifications
Audit Log
Settings

Show different navigation options based on the user's role.

9. Demo Data

Pre-populate the application with realistic fictional records such as:

- DT-2026-001
- DT-2026-002
- DT-2026-003
- DT-2026-004

Use fictional officers, locations, timestamps, test kits, and laboratory results.

Do NOT use real personal information.

10. Dashboard Experience

The first screen after login should immediately communicate:

- What is happening today
- Which samples need attention
- Which laboratory results are available
- Which chain-of-custody actions are pending

Add a prominent “Start New Field Test” button.

11. Error Handling

Add:

- Form validation
- Empty states
- Loading states
- Error messages
- Success notifications/toasts
- Confirmation dialogs
- Invalid QR/sample ID handling

12. Hackathon Demo Flow

Make sure the complete prototype can demonstrate this flow:

Login → Officer Dashboard → New Field Test → Enter Case Details → Register Sample → Generate QR → Record Simulated Field Test → Upload Evidence → Confirm Submission → View Chain of Custody → Laboratory Receives Sample → Enter Simulated Lab Result → Generate Report.

Make this flow polished and easy to demonstrate during a hackathon presentation.

13. Final Requirement

Build the application as a fully functional frontend prototype, not just static screens. Buttons, navigation, forms, filters, sample records, QR simulation, status changes, notifications, audit logs, and dashboard statistics should work using mock/local data.

Prioritize a polished, professional user experience and a convincing hackathon demonstration over unnecessary complexity.