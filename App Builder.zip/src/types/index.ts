export type UserRole = "officer" | "lab" | "admin";

export interface User {
  id: string;
  name: string;
  role: UserRole;
  badge: string;
  unit: string;
}

export type SampleStatus = "collected" | "sealed" | "registered" | "transferred" | "lab_received" | "under_analysis" | "confirmed_negative" | "confirmed_positive" | "invalid" | "retest_required";
export type FieldResult = "negative" | "presumptive_positive" | "invalid" | "pending";
export type LabStatus = "awaiting_lab" | "received" | "under_analysis" | "confirmed_negative" | "confirmed_positive" | "invalid_retest";
export type CoCStatus = "complete" | "partial" | "pending";

export interface Sample {
  id: string;
  caseId: string;
  sampleType: string;
  collectionDate: string;
  collectionTime: string;
  collectionLocation: string;
  containerSeal: string;
  condition: string;
  officerId: string;
  officerName: string;
  subjectRef: string;
  notes: string;
  status: SampleStatus;
  fieldResult: FieldResult;
  labStatus: LabStatus;
  cocStatus: CoCStatus;
  targetSubstance: string;
  testKitId: string;
  kitBatch: string;
  kitExpiry: string;
  testStartTime: string;
  testEndTime: string;
  evidenceCount: number;
  labResult?: string;
  labReportDate?: string;
  labTechnician?: string;
}

export interface CustodyEvent {
  id: string;
  sampleId: string;
  eventType: string;
  timestamp: string;
  personName: string;
  personRole: string;
  location: string;
  action: string;
  signature: string;
  signed: boolean;
}

export interface EvidenceFile {
  id: string;
  sampleId: string;
  fileName: string;
  fileType: "image" | "document" | "video";
  uploadDate: string;
  uploadTime: string;
  officerName: string;
  verified: boolean;
  size: string;
}

export interface Notification {
  id: string;
  type: "sample_received" | "coc_update" | "lab_result" | "invalid_test" | "retest_required" | "missing_info";
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  sampleId?: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  resource: string;
  resourceId: string;
  details: string;
  ipAddress: string;
  result: "success" | "failure";
}
