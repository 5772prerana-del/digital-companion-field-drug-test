import { useState, useEffect } from "react";
import type { User, Sample, LabStatus, Notification } from "./types";
import { MOCK_SAMPLES, MOCK_EVIDENCE, MOCK_NOTIFICATIONS, DEMO_USERS } from "./data/mockData";

import Login from "./views/Login";
import Dashboard from "./views/Dashboard";
import NewFieldTest from "./views/NewFieldTest";
import Samples from "./views/Samples";
import QRScanner from "./views/QRScanner";
import ChainOfCustody from "./views/ChainOfCustody";
import Evidence from "./views/Evidence";
import Laboratory from "./views/Laboratory";
import Reports from "./views/Reports";
import Notifications from "./views/Notifications";
import AdminDashboard from "./views/AdminDashboard";
import AuditLog from "./views/AuditLog";
import Settings from "./views/Settings";

import Sidebar from "./components/layout/Sidebar";
import Header from "./components/layout/Header";

export type ViewName =
  | "dashboard" | "new_test" | "samples" | "qr_scanner"
  | "chain_of_custody" | "evidence" | "laboratory" | "reports"
  | "notifications" | "audit_log" | "admin_dashboard" | "settings";

const LS_USER_KEY = "dtc_user";
const LS_SAMPLES_KEY = "dtc_samples";
const LS_NOTIFS_KEY = "dtc_notifs";

function loadFromLS<T>(key: string, fallback: T): T {
  try {
    const s = localStorage.getItem(key);
    return s ? JSON.parse(s) : fallback;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(LS_USER_KEY);
    if (saved) {
      try {
        const id = JSON.parse(saved) as string;
        return DEMO_USERS.find(u => u.id === id) || null;
      } catch { return null; }
    }
    return null;
  });

  const [currentView, setCurrentView] = useState<ViewName>("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [samples, setSamples] = useState<Sample[]>(() => loadFromLS(LS_SAMPLES_KEY, MOCK_SAMPLES));
  const [notifications, setNotifications] = useState<Notification[]>(() => loadFromLS(LS_NOTIFS_KEY, MOCK_NOTIFICATIONS));
  const [synced] = useState(true);

  // Persist samples
  useEffect(() => {
    localStorage.setItem(LS_SAMPLES_KEY, JSON.stringify(samples));
  }, [samples]);

  // Persist notifications
  useEffect(() => {
    localStorage.setItem(LS_NOTIFS_KEY, JSON.stringify(notifications));
  }, [notifications]);

  const handleLogin = (u: User) => {
    setUser(u);
    localStorage.setItem(LS_USER_KEY, JSON.stringify(u.id));
    // Default view based on role
    if (u.role === "lab") setCurrentView("laboratory");
    else if (u.role === "admin") setCurrentView("admin_dashboard");
    else setCurrentView("dashboard");
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem(LS_USER_KEY);
    setCurrentView("dashboard");
  };

  const handleNewSample = (sample: Sample) => {
    setSamples(prev => [sample, ...prev]);
    const newNotif: Notification = {
      id: `N-${Date.now()}`,
      type: "sample_received",
      title: "New Sample Registered",
      message: `Sample ${sample.id} submitted by ${sample.officerName}. Field result: ${sample.fieldResult}.`,
      timestamp: new Date().toISOString(),
      read: false,
      sampleId: sample.id,
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleUpdateLabStatus = (sampleId: string, status: LabStatus, result?: string) => {
    setSamples(prev => prev.map(s => s.id === sampleId ? {
      ...s,
      labStatus: status,
      labResult: result || s.labResult,
      labReportDate: (status === "confirmed_negative" || status === "confirmed_positive") ? new Date().toISOString().split("T")[0] : s.labReportDate,
    } : s));
    const notif: Notification = {
      id: `N-${Date.now()}`,
      type: "lab_result",
      title: "Lab Status Updated",
      message: `Sample ${sampleId} status updated to: ${status.replace(/_/g, " ")}.`,
      timestamp: new Date().toISOString(),
      read: false,
      sampleId,
    };
    setNotifications(prev => [notif, ...prev]);
  };

  const handleMarkRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleMarkAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  const renderView = () => {
    switch (currentView) {
      case "dashboard": return <Dashboard user={user} onNavigate={setCurrentView} />;
      case "new_test": return <NewFieldTest user={user} onNavigate={setCurrentView} onNewSample={handleNewSample} />;
      case "samples": return <Samples samples={samples} />;
      case "qr_scanner": return <QRScanner samples={samples} />;
      case "chain_of_custody": return <ChainOfCustody samples={samples} />;
      case "evidence": return <Evidence evidence={MOCK_EVIDENCE} />;
      case "laboratory": return <Laboratory samples={samples} onUpdateLabStatus={handleUpdateLabStatus} />;
      case "reports": return <Reports />;
      case "notifications": return <Notifications notifications={notifications} onMarkRead={handleMarkRead} onMarkAllRead={handleMarkAllRead} />;
      case "audit_log": return <AuditLog />;
      case "admin_dashboard": return <AdminDashboard />;
      case "settings": return <Settings user={user} />;
      default: return <Dashboard user={user} onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="flex h-full bg-[--background]">
      <Sidebar
        user={user}
        currentView={currentView}
        onNavigate={setCurrentView}
        onLogout={handleLogout}
        notifCount={unreadCount}
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          currentView={currentView}
          onMenuToggle={() => setMobileMenuOpen(o => !o)}
          synced={synced}
        />
        <main className="flex-1 overflow-y-auto">
          {renderView()}
        </main>
      </div>
    </div>
  );
}
