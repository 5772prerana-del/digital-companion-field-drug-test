import { useState } from "react";
import { CheckCircle2, XCircle, FlaskConical, Upload } from "lucide-react";
import { LabStatusBadge, FieldResultBadge } from "../components/ui/Badge";
import type { Sample, LabStatus } from "../types";

interface LabProps {
  samples: Sample[];
  onUpdateLabStatus: (sampleId: string, status: LabStatus, result?: string) => void;
}

export default function Laboratory({ samples, onUpdateLabStatus }: LabProps) {
  const [selected, setSelected] = useState<Sample | null>(null);
  const [newStatus, setNewStatus] = useState<LabStatus>("received");
  const [labResult, setLabResult] = useState("");
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (!selected) return;
    onUpdateLabStatus(selected.id, newStatus, labResult);
    setSaved(true);
    setTimeout(() => { setSaved(false); setSelected(null); }, 1500);
  };

  const LAB_STATUSES: LabStatus[] = ["received", "under_analysis", "confirmed_negative", "confirmed_positive", "invalid_retest"];
  const statusLabels: Record<LabStatus, string> = {
    awaiting_lab: "Awaiting Lab",
    received: "Received",
    under_analysis: "Under Analysis",
    confirmed_negative: "Confirmed Negative",
    confirmed_positive: "Confirmed Positive",
    invalid_retest: "Invalid / Retest Required",
  };

  const inputCls = "w-full px-3 py-2.5 border border-[--border] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white";

  return (
    <div className="p-4 md:p-6 max-w-6xl">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Sample list */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl border border-[--border] shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-[--border]">
              <h3 className="text-sm font-semibold text-[--foreground]">Samples for Laboratory Processing</h3>
            </div>
            <div className="divide-y divide-[--border]">
              {samples.map(s => (
                <div
                  key={s.id}
                  onClick={() => { setSelected(s); setNewStatus(s.labStatus === "awaiting_lab" ? "received" : s.labStatus); setLabResult(s.labResult || ""); setSaved(false); }}
                  className={`px-4 py-4 hover:bg-blue-50/50 cursor-pointer transition-colors ${selected?.id === s.id ? "bg-blue-50 border-l-2 border-blue-500" : ""}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="font-mono text-sm font-bold text-[--primary]">{s.id}</span>
                      <span className="text-xs text-[--muted-foreground] ml-2">{s.caseId}</span>
                    </div>
                    <LabStatusBadge status={s.labStatus} />
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[--muted-foreground]">
                    <span>{s.sampleType}</span>
                    <span>·</span>
                    <span>{s.targetSubstance}</span>
                    <span>·</span>
                    <span>{s.collectionDate}</span>
                    <FieldResultBadge result={s.fieldResult} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Detail / update panel */}
        <div className="lg:col-span-2">
          {selected ? (
            <div className="bg-white rounded-xl border border-[--border] shadow-sm">
              <div className="px-5 py-4 border-b border-[--border]">
                <h3 className="text-sm font-semibold text-[--foreground]">Update: <span className="font-mono text-[--primary]">{selected.id}</span></h3>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[["Sample Type", selected.sampleType], ["Substance", selected.targetSubstance], ["Collected", selected.collectionDate], ["Officer", selected.officerName]].map(([k, v]) => (
                    <div key={k} className="bg-[--muted] rounded p-2">
                      <div className="text-[--muted-foreground]">{k}</div>
                      <div className="font-medium text-[--foreground] mt-0.5">{v}</div>
                    </div>
                  ))}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[--foreground] mb-1.5">Update Lab Status</label>
                  <select className={inputCls} value={newStatus} onChange={e => setNewStatus(e.target.value as LabStatus)}>
                    {LAB_STATUSES.map(s => <option key={s} value={s}>{statusLabels[s]}</option>)}
                  </select>
                </div>

                {(newStatus === "confirmed_negative" || newStatus === "confirmed_positive") && (
                  <div>
                    <label className="block text-sm font-medium text-[--foreground] mb-1.5">Laboratory Result Details</label>
                    <textarea
                      className={`${inputCls} resize-none`}
                      rows={3}
                      placeholder="e.g. Cocaine HCl — 89.2% purity"
                      value={labResult}
                      onChange={e => setLabResult(e.target.value)}
                    />
                  </div>
                )}

                <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center cursor-pointer hover:border-blue-300 hover:bg-blue-50/30 transition-colors">
                  <Upload size={18} className="text-gray-400 mx-auto mb-1.5" />
                  <p className="text-xs text-[--muted-foreground]">Upload Laboratory Report (PDF)</p>
                </div>

                {saved ? (
                  <div className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-sm text-emerald-700">
                    <CheckCircle2 size={16} />Saved successfully
                  </div>
                ) : (
                  <div className="flex gap-3">
                    <button onClick={handleSave}
                      className="flex-1 py-2.5 bg-[#1B3A6B] text-white rounded-lg text-sm font-semibold hover:bg-[#162f58] transition-colors flex items-center justify-center gap-2">
                      <FlaskConical size={15} />Save Update
                    </button>
                    <button onClick={() => setSelected(null)}
                      className="px-4 py-2.5 border border-[--border] text-[--foreground] rounded-lg text-sm hover:bg-gray-50 transition-colors">
                      <XCircle size={15} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-[--border] p-6 text-center text-sm text-[--muted-foreground]">
              <FlaskConical size={28} className="text-gray-300 mx-auto mb-2" />
              Select a sample to update its laboratory status
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
