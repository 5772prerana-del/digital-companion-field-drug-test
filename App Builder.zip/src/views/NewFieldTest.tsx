import { useState } from "react";
import { CheckCircle2, ChevronRight, AlertCircle, Upload, QrCode } from "lucide-react";
import type { User } from "../types";
import type { ViewName } from "../App";

const STEPS = ["Case Information", "Sample Information", "Field Test", "Verification"];

function generateId() {
  const n = Math.floor(Math.random() * 900) + 100;
  return `DT-2026-0${n}`;
}

function generateSealId() {
  return `SEAL-${Math.floor(Math.random() * 9000) + 1000}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`;
}

interface NewFieldTestProps {
  user: User;
  onNavigate: (view: ViewName) => void;
  onNewSample: (sample: import("../types").Sample) => void;
}

export default function NewFieldTest({ user, onNavigate, onNewSample }: NewFieldTestProps) {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [sampleId] = useState(generateId);
  const [sealId] = useState(generateSealId);

  const now = new Date();
  const todayStr = now.toISOString().split("T")[0];
  const timeStr = now.toTimeString().slice(0, 5);

  const [caseInfo, setCaseInfo] = useState({
    caseId: `CASE-2026-0${Math.floor(Math.random() * 900) + 100}`,
    date: todayStr,
    time: timeStr,
    location: "",
    officerId: user.id,
    subjectRef: "",
    notes: "",
  });

  const [sampleInfo, setSampleInfo] = useState({
    sampleType: "Powder",
    collectionDate: todayStr,
    collectionTime: timeStr,
    collectionLocation: caseInfo.location,
    containerSeal: sealId,
    condition: "Good",
  });

  const [testInfo, setTestInfo] = useState({
    testKitId: `TK-NARCO-${Math.floor(Math.random() * 900) + 100}`,
    kitBatch: `BATCH-2026-${(now.getMonth() + 1).toString().padStart(2, "0")}A`,
    kitExpiry: "2027-06-30",
    testStartTime: timeStr,
    testEndTime: "",
    targetSubstance: "Cocaine / Stimulants",
    result: "negative" as "negative" | "presumptive_positive" | "invalid",
  });

  const canProceed = [
    caseInfo.location.trim() !== "" && caseInfo.subjectRef.trim() !== "",
    sampleInfo.collectionLocation.trim() !== "",
    testInfo.testEndTime !== "" && testInfo.targetSubstance !== "",
    true,
  ];

  const handleSubmit = () => {
    const newSample: import("../types").Sample = {
      id: sampleId,
      caseId: caseInfo.caseId,
      sampleType: sampleInfo.sampleType,
      collectionDate: sampleInfo.collectionDate,
      collectionTime: sampleInfo.collectionTime,
      collectionLocation: sampleInfo.collectionLocation,
      containerSeal: sampleInfo.containerSeal,
      condition: sampleInfo.condition,
      officerId: user.id,
      officerName: user.name,
      subjectRef: caseInfo.subjectRef,
      notes: caseInfo.notes,
      status: "registered",
      fieldResult: testInfo.result,
      labStatus: "awaiting_lab",
      cocStatus: "partial",
      targetSubstance: testInfo.targetSubstance,
      testKitId: testInfo.testKitId,
      kitBatch: testInfo.kitBatch,
      kitExpiry: testInfo.kitExpiry,
      testStartTime: testInfo.testStartTime,
      testEndTime: testInfo.testEndTime,
      evidenceCount: 0,
    };
    onNewSample(newSample);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[60vh]">
        <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-lg border border-[--border]">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-100 rounded-full mb-4">
            <CheckCircle2 size={32} className="text-emerald-600" />
          </div>
          <h2 className="text-xl font-bold text-[--foreground] mb-2">Test Submitted</h2>
          <p className="text-sm text-[--muted-foreground] mb-4">
            Sample <span className="font-mono font-semibold text-[--primary]">{sampleId}</span> has been registered and saved locally.
          </p>
          <div className="bg-[--muted] rounded-lg p-4 mb-6 text-left space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-[--muted-foreground]">Sample ID</span><span className="font-mono font-semibold">{sampleId}</span></div>
            <div className="flex justify-between"><span className="text-[--muted-foreground]">Case ID</span><span className="font-mono">{caseInfo.caseId}</span></div>
            <div className="flex justify-between"><span className="text-[--muted-foreground]">Result</span>
              <span className={`font-medium ${testInfo.result === "negative" ? "text-emerald-600" : testInfo.result === "presumptive_positive" ? "text-amber-600" : "text-gray-500"}`}>
                {testInfo.result === "negative" ? "Negative" : testInfo.result === "presumptive_positive" ? "Presumptive Positive" : "Invalid"}
              </span>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => onNavigate("samples")} className="flex-1 py-2.5 bg-[#1B3A6B] text-white rounded-lg text-sm font-semibold hover:bg-[#162f58] transition-colors">
              View Samples
            </button>
            <button onClick={() => onNavigate("chain_of_custody")} className="flex-1 py-2.5 border border-[--border] text-[--foreground] rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
              Chain of Custody
            </button>
          </div>
        </div>
      </div>
    );
  }

  const inputCls = "w-full px-3 py-2.5 border border-[--border] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white";
  const labelCls = "block text-sm font-medium text-[--foreground] mb-1.5";
  const req = <span className="text-red-500 ml-0.5">*</span>;

  return (
    <div className="p-4 md:p-6 max-w-3xl">
      {/* Step indicator */}
      <div className="bg-white rounded-xl border border-[--border] p-4 mb-5 shadow-sm">
        <div className="flex items-center gap-1">
          {STEPS.map((s, i) => (
            <div key={i} className="flex items-center gap-1 flex-1 min-w-0">
              <div className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                i < step ? "bg-emerald-500 text-white" : i === step ? "bg-[#1B3A6B] text-white" : "bg-gray-100 text-gray-400"
              }`}>
                {i < step ? <CheckCircle2 size={14} /> : i + 1}
              </div>
              <span className={`text-xs font-medium hidden sm:block truncate ${i === step ? "text-[--foreground]" : "text-[--muted-foreground]"}`}>{s}</span>
              {i < STEPS.length - 1 && <ChevronRight size={14} className="text-gray-300 flex-shrink-0" />}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-[--border] shadow-sm">
        <div className="px-6 py-4 border-b border-[--border]">
          <h2 className="font-semibold text-[--foreground]">Step {step + 1}: {STEPS[step]}</h2>
          <p className="text-xs text-[--muted-foreground] mt-0.5">Sample ID: <span className="font-mono font-semibold text-[--primary]">{sampleId}</span></p>
        </div>

        <div className="p-6">
          {step === 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><label className={labelCls}>Case / Reference ID {req}</label><input className={inputCls} value={caseInfo.caseId} onChange={e => setCaseInfo(p => ({ ...p, caseId: e.target.value }))} /></div>
              <div><label className={labelCls}>Date {req}</label><input type="date" className={inputCls} value={caseInfo.date} onChange={e => setCaseInfo(p => ({ ...p, date: e.target.value }))} /></div>
              <div><label className={labelCls}>Time {req}</label><input type="time" className={inputCls} value={caseInfo.time} onChange={e => setCaseInfo(p => ({ ...p, time: e.target.value }))} /></div>
              <div><label className={labelCls}>Testing Location {req}</label><input className={inputCls} placeholder="e.g. Riverside Industrial Park" value={caseInfo.location} onChange={e => setCaseInfo(p => ({ ...p, location: e.target.value }))} /></div>
              <div><label className={labelCls}>Officer ID</label><input className={`${inputCls} bg-gray-50`} value={caseInfo.officerId} readOnly /></div>
              <div><label className={labelCls}>Subject / Reference ID {req}</label><input className={inputCls} placeholder="e.g. SUBJ-2026-120" value={caseInfo.subjectRef} onChange={e => setCaseInfo(p => ({ ...p, subjectRef: e.target.value }))} /></div>
              <div className="sm:col-span-2"><label className={labelCls}>Notes</label><textarea className={`${inputCls} resize-none`} rows={3} placeholder="Additional scene notes..." value={caseInfo.notes} onChange={e => setCaseInfo(p => ({ ...p, notes: e.target.value }))} /></div>
            </div>
          )}

          {step === 1 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={labelCls}>Sample Type {req}</label>
                <select className={inputCls} value={sampleInfo.sampleType} onChange={e => setSampleInfo(p => ({ ...p, sampleType: e.target.value }))}>
                  {["Powder", "Tablet", "Liquid", "Plant Material", "Residue", "Other"].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div><label className={labelCls}>Sample ID (auto-generated)</label><input className={`${inputCls} bg-gray-50 font-mono text-[--primary]`} value={sampleId} readOnly /></div>
              <div><label className={labelCls}>Collection Date</label><input type="date" className={inputCls} value={sampleInfo.collectionDate} onChange={e => setSampleInfo(p => ({ ...p, collectionDate: e.target.value }))} /></div>
              <div><label className={labelCls}>Collection Time</label><input type="time" className={inputCls} value={sampleInfo.collectionTime} onChange={e => setSampleInfo(p => ({ ...p, collectionTime: e.target.value }))} /></div>
              <div><label className={labelCls}>Collection Location {req}</label><input className={inputCls} placeholder="Exact location" value={sampleInfo.collectionLocation} onChange={e => setSampleInfo(p => ({ ...p, collectionLocation: e.target.value }))} /></div>
              <div><label className={labelCls}>Container / Seal Number</label><input className={`${inputCls} font-mono`} value={sampleInfo.containerSeal} onChange={e => setSampleInfo(p => ({ ...p, containerSeal: e.target.value }))} /></div>
              <div>
                <label className={labelCls}>Sample Condition</label>
                <select className={inputCls} value={sampleInfo.condition} onChange={e => setSampleInfo(p => ({ ...p, condition: e.target.value }))}>
                  {["Good", "Damaged", "Contaminated", "Unknown"].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="sm:col-span-2 flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <QrCode size={28} className="text-blue-600 flex-shrink-0" />
                <div>
                  <div className="text-sm font-semibold text-blue-800">QR Code will be generated</div>
                  <div className="text-xs text-blue-600">A unique QR barcode for <span className="font-mono">{sampleId}</span> will be created on submission.</div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><label className={labelCls}>Test Kit ID {req}</label><input className={`${inputCls} font-mono`} value={testInfo.testKitId} onChange={e => setTestInfo(p => ({ ...p, testKitId: e.target.value }))} /></div>
              <div><label className={labelCls}>Kit Batch Number</label><input className={`${inputCls} font-mono`} value={testInfo.kitBatch} onChange={e => setTestInfo(p => ({ ...p, kitBatch: e.target.value }))} /></div>
              <div><label className={labelCls}>Kit Expiry Date</label><input type="date" className={inputCls} value={testInfo.kitExpiry} onChange={e => setTestInfo(p => ({ ...p, kitExpiry: e.target.value }))} /></div>
              <div>
                <label className={labelCls}>Target Substance / Category {req}</label>
                <select className={inputCls} value={testInfo.targetSubstance} onChange={e => setTestInfo(p => ({ ...p, targetSubstance: e.target.value }))}>
                  {["Cocaine / Stimulants", "MDMA / Amphetamines", "Cannabis / THC", "Heroin / Opiates", "GHB / Depressants", "Methamphetamine", "Other / Unknown"].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
              <div><label className={labelCls}>Test Start Time</label><input type="time" className={inputCls} value={testInfo.testStartTime} onChange={e => setTestInfo(p => ({ ...p, testStartTime: e.target.value }))} /></div>
              <div><label className={labelCls}>Test End Time {req}</label><input type="time" className={inputCls} value={testInfo.testEndTime} onChange={e => setTestInfo(p => ({ ...p, testEndTime: e.target.value }))} /></div>
              <div className="sm:col-span-2">
                <label className={labelCls}>Field Test Result {req}</label>
                <div className="grid grid-cols-3 gap-3">
                  {(["negative", "presumptive_positive", "invalid"] as const).map(r => {
                    const labels = { negative: "Negative", presumptive_positive: "Presumptive Positive", invalid: "Invalid" };
                    const colors = {
                      negative: testInfo.result === r ? "bg-emerald-600 text-white border-emerald-600" : "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100",
                      presumptive_positive: testInfo.result === r ? "bg-amber-500 text-white border-amber-500" : "bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100",
                      invalid: testInfo.result === r ? "bg-gray-500 text-white border-gray-500" : "bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100",
                    };
                    return (
                      <button key={r} type="button" onClick={() => setTestInfo(p => ({ ...p, result: r }))}
                        className={`py-3 rounded-lg text-sm font-semibold border transition-all ${colors[r]}`}>
                        {labels[r]}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className={labelCls}>Upload Test Strip Photo</label>
                <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center hover:border-blue-300 hover:bg-blue-50/50 transition-colors cursor-pointer">
                  <Upload size={24} className="text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-[--muted-foreground]">Click to upload or drag and drop</p>
                  <p className="text-xs text-gray-400 mt-1">PNG, JPG up to 10MB</p>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700">
                <AlertCircle size={16} />
                Please review all information before submitting. This record will be immutable once confirmed.
              </div>

              {[
                { title: "Case Information", fields: [
                  ["Case ID", caseInfo.caseId], ["Date / Time", `${caseInfo.date} ${caseInfo.time}`],
                  ["Location", caseInfo.location], ["Subject Ref", caseInfo.subjectRef],
                  ["Officer", user.name], ["Notes", caseInfo.notes || "—"],
                ]},
                { title: "Sample Information", fields: [
                  ["Sample ID", sampleId], ["Type", sampleInfo.sampleType],
                  ["Collection", `${sampleInfo.collectionDate} ${sampleInfo.collectionTime}`],
                  ["Location", sampleInfo.collectionLocation], ["Seal", sampleInfo.containerSeal],
                  ["Condition", sampleInfo.condition],
                ]},
                { title: "Field Test", fields: [
                  ["Test Kit", testInfo.testKitId], ["Batch", testInfo.kitBatch],
                  ["Expiry", testInfo.kitExpiry], ["Substance", testInfo.targetSubstance],
                  ["Duration", `${testInfo.testStartTime} – ${testInfo.testEndTime}`],
                  ["Result", testInfo.result === "negative" ? "Negative" : testInfo.result === "presumptive_positive" ? "Presumptive Positive" : "Invalid"],
                ]},
              ].map(section => (
                <div key={section.title} className="border border-[--border] rounded-lg overflow-hidden">
                  <div className="px-4 py-2.5 bg-[--muted] border-b border-[--border]">
                    <span className="text-xs font-semibold text-[--foreground] uppercase tracking-wide">{section.title}</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-px bg-[--border]">
                    {section.fields.map(([k, v]) => (
                      <div key={k} className="bg-white px-4 py-2.5">
                        <div className="text-xs text-[--muted-foreground]">{k}</div>
                        <div className="text-sm font-medium text-[--foreground] mt-0.5 truncate">{v}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-[--border] flex justify-between">
          <button
            onClick={() => setStep(s => s - 1)}
            disabled={step === 0}
            className="px-5 py-2 border border-[--border] text-[--foreground] rounded-lg text-sm font-medium disabled:opacity-40 hover:bg-gray-50 transition-colors"
          >
            Back
          </button>
          <button
            onClick={step < 3 ? () => setStep(s => s + 1) : handleSubmit}
            disabled={!canProceed[step]}
            className="px-6 py-2 bg-[#1B3A6B] text-white rounded-lg text-sm font-semibold disabled:opacity-40 hover:bg-[#162f58] transition-colors"
          >
            {step < 3 ? "Continue" : "Confirm & Submit"}
          </button>
        </div>
      </div>
    </div>
  );
}
