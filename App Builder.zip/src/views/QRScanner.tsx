import { useState } from "react";
import { QrCode, Search, CheckCircle2, AlertCircle, Scan } from "lucide-react";
import { FieldResultBadge, LabStatusBadge, CoCBadge } from "../components/ui/Badge";
import type { Sample } from "../types";

interface QRScannerProps {
  samples: Sample[];
}

export default function QRScanner({ samples }: QRScannerProps) {
  const [mode, setMode] = useState<"camera" | "manual">("camera");
  const [manualId, setManualId] = useState("");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<Sample | null>(null);
  const [notFound, setNotFound] = useState(false);

  const lookup = (id: string) => {
    const s = samples.find(sample => sample.id.toLowerCase() === id.toLowerCase().trim());
    if (s) {
      setResult(s);
      setNotFound(false);
    } else {
      setResult(null);
      setNotFound(true);
    }
  };

  const simulateScan = (sample: Sample) => {
    setScanning(true);
    setResult(null);
    setNotFound(false);
    setTimeout(() => {
      setScanning(false);
      setResult(sample);
    }, 1500);
  };

  const reset = () => {
    setResult(null);
    setNotFound(false);
    setManualId("");
    setScanning(false);
  };

  return (
    <div className="p-4 md:p-6 max-w-2xl">
      <div className="bg-white rounded-xl border border-[--border] shadow-sm overflow-hidden mb-4">
        {/* Tabs */}
        <div className="flex border-b border-[--border]">
          {(["camera", "manual"] as const).map(m => (
            <button key={m} onClick={() => { setMode(m); reset(); }}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${mode === m ? "bg-[--primary] text-white" : "text-[--muted-foreground] hover:bg-gray-50"}`}>
              {m === "camera" ? "Camera Scan" : "Manual Entry"}
            </button>
          ))}
        </div>

        {mode === "camera" ? (
          <div className="p-6">
            <div className="relative bg-gray-900 rounded-xl overflow-hidden aspect-video flex items-center justify-center mb-4">
              <div className="absolute inset-0 bg-gradient-to-b from-gray-800 to-gray-900" />
              {scanning ? (
                <div className="relative z-10 flex flex-col items-center gap-3">
                  <div className="w-48 h-48 border-2 border-blue-400 rounded-lg relative">
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-blue-400 animate-bounce" style={{ animationDuration: "1s" }} />
                    <div className="absolute top-2 left-2 w-6 h-6 border-t-2 border-l-2 border-blue-400" />
                    <div className="absolute top-2 right-2 w-6 h-6 border-t-2 border-r-2 border-blue-400" />
                    <div className="absolute bottom-2 left-2 w-6 h-6 border-b-2 border-l-2 border-blue-400" />
                    <div className="absolute bottom-2 right-2 w-6 h-6 border-b-2 border-r-2 border-blue-400" />
                  </div>
                  <p className="text-blue-300 text-sm animate-pulse">Scanning...</p>
                </div>
              ) : (
                <div className="relative z-10 flex flex-col items-center gap-3">
                  <Scan size={48} className="text-gray-500" />
                  <p className="text-gray-400 text-sm">Camera preview (simulated)</p>
                </div>
              )}
            </div>
            <p className="text-xs text-center text-[--muted-foreground] mb-4">Select a demo sample to simulate scanning its QR code:</p>
            <div className="grid grid-cols-2 gap-2">
              {samples.map(s => (
                <button key={s.id} onClick={() => simulateScan(s)} disabled={scanning}
                  className="flex items-center gap-2 px-3 py-2 bg-[--muted] hover:bg-blue-50 border border-[--border] hover:border-blue-200 rounded-lg text-sm transition-colors disabled:opacity-50">
                  <QrCode size={16} className="text-blue-500 flex-shrink-0" />
                  <span className="font-mono font-semibold text-[--primary] text-xs">{s.id}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-6">
            <p className="text-sm text-[--muted-foreground] mb-3">Enter a sample ID to look up its details:</p>
            <div className="flex gap-2">
              <input
                className="flex-1 px-3 py-2.5 border border-[--border] rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                placeholder="e.g. DT-2026-001"
                value={manualId}
                onChange={e => setManualId(e.target.value)}
                onKeyDown={e => e.key === "Enter" && lookup(manualId)}
              />
              <button onClick={() => lookup(manualId)}
                className="px-4 py-2.5 bg-[#1B3A6B] text-white rounded-lg text-sm font-semibold hover:bg-[#162f58] transition-colors flex items-center gap-2">
                <Search size={15} />
                Lookup
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Result */}
      {result && (
        <div className="bg-white rounded-xl border border-emerald-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 bg-emerald-50 border-b border-emerald-200 flex items-center gap-2">
            <CheckCircle2 size={18} className="text-emerald-600" />
            <span className="text-sm font-semibold text-emerald-700">Sample Found</span>
          </div>
          <div className="p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xl font-bold text-[--primary]">{result.id}</span>
              <div className="flex gap-2">
                <FieldResultBadge result={result.fieldResult} />
                <LabStatusBadge status={result.labStatus} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {[
                ["Case ID", result.caseId],
                ["Sample Type", result.sampleType],
                ["Collected", `${result.collectionDate} ${result.collectionTime}`],
                ["Location", result.collectionLocation],
                ["Officer", result.officerName],
                ["Target Substance", result.targetSubstance],
              ].map(([k, v]) => (
                <div key={k} className="bg-[--muted] rounded-lg p-2.5">
                  <div className="text-xs text-[--muted-foreground]">{k}</div>
                  <div className="text-sm font-medium mt-0.5 truncate">{v}</div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between pt-1">
              <div className="text-xs text-[--muted-foreground]">Chain of Custody</div>
              <CoCBadge status={result.cocStatus} />
            </div>
          </div>
          <div className="px-5 py-3 border-t border-[--border]">
            <button onClick={reset} className="text-xs text-blue-600 hover:underline">Scan another sample</button>
          </div>
        </div>
      )}

      {notFound && (
        <div className="bg-white rounded-xl border border-red-200 shadow-sm p-5 flex items-start gap-3">
          <AlertCircle size={20} className="text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-sm font-semibold text-red-700">Sample Not Found</div>
            <div className="text-sm text-red-600 mt-0.5">No sample with ID &ldquo;{manualId}&rdquo; exists. Please verify the ID and try again.</div>
            <button onClick={reset} className="text-xs text-blue-600 hover:underline mt-2">Try again</button>
          </div>
        </div>
      )}
    </div>
  );
}
