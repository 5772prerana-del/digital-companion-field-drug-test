import { useState } from "react";
import { ShieldCheck, Eye, EyeOff, AlertCircle } from "lucide-react";
import { DEMO_CREDENTIALS, DEMO_USERS } from "../data/mockData";
import type { User, UserRole } from "../types";

interface LoginProps {
  onLogin: (user: User) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<UserRole>("officer");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    setTimeout(() => {
      const cred = DEMO_CREDENTIALS.find(c => c.email === email && c.password === password && c.role === role);
      if (cred) {
        const user = DEMO_USERS.find(u => u.role === cred.role)!;
        onLogin(user);
      } else {
        setError("Invalid credentials. Use the demo credentials below.");
      }
      setLoading(false);
    }, 800);
  };

  const quickLogin = (cred: typeof DEMO_CREDENTIALS[number]) => {
    setEmail(cred.email);
    setPassword(cred.password);
    setRole(cred.role);
  };

  return (
    <div className="min-h-screen bg-[#0F2347] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-2xl mb-4">
            <ShieldCheck size={32} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-1">DrugTest Companion</h1>
          <p className="text-blue-300 text-sm">Field Drug Testing Management System</p>
          <span className="inline-block mt-2 text-[10px] bg-yellow-400/20 text-yellow-300 border border-yellow-400/30 px-2 py-0.5 rounded font-mono">
            PROTOTYPE · DEMO DATA ONLY
          </span>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Sign In</h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Role */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
              <div className="grid grid-cols-3 gap-2">
                {(["officer", "lab", "admin"] as UserRole[]).map(r => {
                  const labels: Record<UserRole, string> = { officer: "Officer", lab: "Lab Tech", admin: "Admin" };
                  return (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      className={`py-2 px-3 rounded-lg text-sm font-medium border transition-all ${
                        role === r
                          ? "bg-[#1B3A6B] text-white border-[#1B3A6B]"
                          : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      {labels[r]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Officer ID / Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="officer@demo.gov"
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                <AlertCircle size={15} />
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-[#1B3A6B] hover:bg-[#162f58] text-white font-semibold rounded-lg text-sm transition-colors disabled:opacity-60"
            >
              {loading ? "Authenticating..." : "Sign In"}
            </button>

            <button type="button" className="w-full text-center text-xs text-blue-600 hover:underline">
              Forgot password?
            </button>
          </form>
        </div>

        {/* Demo credentials */}
        <div className="mt-4 bg-white/10 rounded-xl p-4">
          <p className="text-xs text-blue-300 font-medium mb-2 text-center">Demo Credentials</p>
          <div className="space-y-1.5">
            {DEMO_CREDENTIALS.map(cred => (
              <button
                key={cred.role}
                onClick={() => quickLogin(cred)}
                className="w-full flex items-center justify-between px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors text-left"
              >
                <div>
                  <span className="text-xs font-semibold text-white">{cred.label}</span>
                  <span className="text-xs text-blue-300 ml-2 font-mono">{cred.email}</span>
                </div>
                <span className="text-[10px] text-blue-300 font-mono">demo1234</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
