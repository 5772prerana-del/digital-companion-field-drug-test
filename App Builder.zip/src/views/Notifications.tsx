import { useState } from "react";
import { Bell, FlaskConical, Link2, AlertTriangle, RefreshCw, Info, CheckCheck } from "lucide-react";
import type { Notification } from "../types";

const TYPE_META: Record<Notification["type"], { icon: React.ComponentType<{ size?: number; className?: string }>; color: string; bg: string }> = {
  lab_result: { icon: FlaskConical, color: "text-blue-600", bg: "bg-blue-50" },
  coc_update: { icon: Link2, color: "text-violet-600", bg: "bg-violet-50" },
  sample_received: { icon: Bell, color: "text-emerald-600", bg: "bg-emerald-50" },
  invalid_test: { icon: AlertTriangle, color: "text-red-600", bg: "bg-red-50" },
  retest_required: { icon: RefreshCw, color: "text-orange-600", bg: "bg-orange-50" },
  missing_info: { icon: Info, color: "text-amber-600", bg: "bg-amber-50" },
};

interface NotificationsProps {
  notifications: Notification[];
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
}

export default function Notifications({ notifications, onMarkRead, onMarkAllRead }: NotificationsProps) {
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const unreadCount = notifications.filter(n => !n.read).length;
  const shown = filter === "unread" ? notifications.filter(n => !n.read) : notifications;

  const formatTime = (ts: string) => {
    const d = new Date(ts);
    return d.toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="p-4 md:p-6 max-w-3xl">
      <div className="bg-white rounded-xl border border-[--border] shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-[--border] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell size={16} className="text-[--muted-foreground]" />
            <span className="text-sm font-semibold text-[--foreground]">Notifications</span>
            {unreadCount > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold rounded-full px-2 py-0.5">{unreadCount}</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex rounded-lg border border-[--border] overflow-hidden text-xs">
              {(["all", "unread"] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 font-medium capitalize transition-colors ${filter === f ? "bg-[#1B3A6B] text-white" : "bg-white text-[--muted-foreground] hover:bg-gray-50"}`}>
                  {f}
                </button>
              ))}
            </div>
            {unreadCount > 0 && (
              <button onClick={onMarkAllRead}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-[--muted-foreground] hover:text-[--foreground] transition-colors">
                <CheckCheck size={14} />Mark all read
              </button>
            )}
          </div>
        </div>

        {shown.length === 0 ? (
          <div className="text-center py-16 text-sm text-[--muted-foreground]">
            <Bell size={28} className="text-gray-200 mx-auto mb-2" />
            {filter === "unread" ? "No unread notifications." : "No notifications."}
          </div>
        ) : (
          <div className="divide-y divide-[--border]">
            {shown.map(notif => {
              const meta = TYPE_META[notif.type];
              const Icon = meta.icon;
              return (
                <div
                  key={notif.id}
                  onClick={() => !notif.read && onMarkRead(notif.id)}
                  className={`flex items-start gap-4 px-5 py-4 transition-colors cursor-pointer ${
                    notif.read ? "opacity-70" : "hover:bg-blue-50/40"
                  }`}
                >
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${meta.bg}`}>
                    <Icon size={16} className={meta.color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className={`text-sm font-semibold ${notif.read ? "text-[--muted-foreground]" : "text-[--foreground]"}`}>{notif.title}</div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {!notif.read && <span className="w-2 h-2 rounded-full bg-blue-500" />}
                        <span className="text-xs text-[--muted-foreground]">{formatTime(notif.timestamp)}</span>
                      </div>
                    </div>
                    <p className="text-xs text-[--muted-foreground] mt-0.5">{notif.message}</p>
                    {notif.sampleId && (
                      <span className="inline-block mt-1.5 text-[10px] font-mono bg-[--muted] px-1.5 py-0.5 rounded text-[--primary] font-semibold">{notif.sampleId}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
