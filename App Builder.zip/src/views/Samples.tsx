import { useState } from "react";
import { Search, Filter, X, ChevronRight } from "lucide-react";
import { FieldResultBadge, LabStatusBadge, CoCBadge } from "../components/ui/Badge";
import type { Sample, FieldResult, LabStatus } from "../types";

interface SamplesProps {
  samples: Sample[];
}

export default function Samples({ samples }: SamplesProps) {
  const [search, setSearch] = useState("");
  const [filterResult, setFilterResult] = useState<FieldResult | "all">("all");
  const [filterLab, setFilterLab] = useState<LabStatus | "all">("all");
  const [filterType, setFilterType] = useState("all");
  const [selected, setSelected] = useState<Sample | null>(null);

  const sampleTypes = ["all", ...Array.from(new Set(samples.map(s => s.sampleType)))];

  const filtered = samples.filter(s => {
    const matchSearch = s.id.toLowerCase().includes(search.toLowerCase()) ||
      s.caseId.toLowerCase().includes(search.toLowerCase()) ||
      s.subjectRef.toLowerCase().includes(search.toLowerCase()) ||
      s.targetSubstance.toLowerCase().includes(search.toLowerCase());
    const matchResult = filterResult === "all" || s.fieldResult === filterResult;
    const matchLab = filterLab === "all" || s.labStatus === filterLab;
    const matchType = filterType === "all" || s.sampleType === filterType;
    return matchSearch && matchResult && matchLab && matchType;
  });

  if (selected) {
    return (
      <div className="p-4 md:p-6 max-w-4xl">
        <button onClick={() => setSelected(null)} className="flex items-center gap-2 text-sm text-[--muted-foreground] hover:text-[--foreground] mb-4 transition-colors">
          <X size={16} /> Back to samples
        </button>
        <div className="bg-white rounded-xl border border-[--border] shadow-sm">
          <div className="px-6 py-5 border-b border-[--border] flex items-start justify-between">
            <div>
              <h2 className="text-lg font-bold font-mono text-[--primary]">{selected.id}</h2>
              <p className="text-sm text-[--muted-foreground]">Case: {selected.caseId} · {selected.collectionDate}</p>
            </div>
            <div className="flex gap-2">
              <FieldResultBadge result={selected.fieldResult} />
              <LabStatusBadge status={selected.labStatus} />
            </div>
          </div>
          <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              ["Sample ID", selected.id, true],
              ["Case ID", selected.caseId, true],
              ["Sample Type", selected.sampleType, false],
              ["Collection Date", selected.collectionDate, false],
              ["Collection Time", selected.collectionTime, false],
              ["Location", selected.collectionLocation, false],
              ["Container Seal", selected.containerSeal, true],
              ["Condition", selected.condition, false],
              ["Officer", selected.officerName, false],
              ["Subject Ref", selected.subjectRef, true],
              ["Target Substance", selected.targetSubstance, false],
              ["Test Kit", selected.testKitId, true],
              ["Kit Batch", selected.kitBatch, true],
              ["Kit Expiry", selected.kitExpiry, false],
              ["Test Duration", `${selected.testStartTime} – ${selected.testEndTime}`, false],
              ["Evidence Files", `${selected.evidenceCount} file(s)`, false],
            ].map(([k, v, mono]) => (
              <div key={k as string} className="bg-[--muted] rounded-lg p-3">
                <div className="text-xs text-[--muted-foreground] mb-0.5">{k as string}</div>
                <div className={`text-sm font-medium text-[--foreground] ${mono ? "font-mono" : ""}`}>{v as string}</div>
              </div>
            ))}
          </div>
          {selected.notes && (
            <div className="px-6 pb-4">
              <div className="text-xs text-[--muted-foreground] mb-1">Notes</div>
              <p className="text-sm text-[--foreground] bg-[--muted] rounded-lg p-3">{selected.notes}</p>
            </div>
          )}
          {selected.labResult && (
            <div className="px-6 pb-6">
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="text-sm font-semibold text-red-700 mb-1">Laboratory Confirmed Result</div>
                <div className="text-sm text-red-800">{selected.labResult}</div>
                <div className="text-xs text-red-600 mt-1">{selected.labReportDate} · {selected.labTechnician}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            className="w-full pl-9 pr-4 py-2.5 border border-[--border] rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Search by ID, case, subject, substance..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <select className="px-3 py-2.5 border border-[--border] rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={filterType} onChange={e => setFilterType(e.target.value)}>
            {sampleTypes.map(t => <option key={t} value={t}>{t === "all" ? "All Types" : t}</option>)}
          </select>
          <select className="px-3 py-2.5 border border-[--border] rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={filterResult} onChange={e => setFilterResult(e.target.value as FieldResult | "all")}>
            <option value="all">All Results</option>
            <option value="negative">Negative</option>
            <option value="presumptive_positive">Presumptive Positive</option>
            <option value="invalid">Invalid</option>
          </select>
          <select className="px-3 py-2.5 border border-[--border] rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={filterLab} onChange={e => setFilterLab(e.target.value as LabStatus | "all")}>
            <option value="all">All Lab Status</option>
            <option value="awaiting_lab">Awaiting Lab</option>
            <option value="received">Received</option>
            <option value="under_analysis">Under Analysis</option>
            <option value="confirmed_negative">Confirmed Negative</option>
            <option value="confirmed_positive">Confirmed Positive</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-[--border] shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-[--border] flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-medium text-[--foreground]">
            <Filter size={15} className="text-[--muted-foreground]" />
            {filtered.length} sample{filtered.length !== 1 ? "s" : ""}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[--muted] border-b border-[--border]">
                {["Sample ID", "Case ID", "Type", "Date", "Field Result", "Lab Status", "CoC", ""].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-[--muted-foreground] uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-[--muted-foreground] text-sm">No samples match the current filters.</td></tr>
              ) : filtered.map(s => (
                <tr
                  key={s.id}
                  className="border-b border-[--border] hover:bg-blue-50/50 cursor-pointer transition-colors"
                  onClick={() => setSelected(s)}
                >
                  <td className="px-4 py-3 font-mono font-semibold text-[--primary] whitespace-nowrap">{s.id}</td>
                  <td className="px-4 py-3 font-mono text-xs text-[--muted-foreground] whitespace-nowrap">{s.caseId}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{s.sampleType}</td>
                  <td className="px-4 py-3 text-[--muted-foreground] whitespace-nowrap">{s.collectionDate}</td>
                  <td className="px-4 py-3 whitespace-nowrap"><FieldResultBadge result={s.fieldResult} /></td>
                  <td className="px-4 py-3 whitespace-nowrap"><LabStatusBadge status={s.labStatus} /></td>
                  <td className="px-4 py-3 whitespace-nowrap"><CoCBadge status={s.cocStatus} /></td>
                  <td className="px-4 py-3"><ChevronRight size={16} className="text-gray-400" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
