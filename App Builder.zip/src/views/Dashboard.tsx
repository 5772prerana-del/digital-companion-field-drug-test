import { FlaskConical, Clock, CheckCircle2, AlertTriangle, Microscope, PlusCircle, QrCode, FileStack, BarChart3, TrendingUp } from "lucide-react";
import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis, YAxis, PieChart, Pie, Cell } from "recharts";
import { MOCK_SAMPLES, CHART_TESTS_OVER_TIME, CHART_RESULT_DISTRIBUTION } from "../data/mockData";
import { FieldResultBadge, LabStatusBadge } from "../components/ui/Badge";
import type { User } from "../types";
import type { ViewName } from "../App";

interface DashboardProps {
  user: User;
  onNavigate: (view: ViewName) => void;
}

export default function Dashboard({ user, onNavigate }: DashboardProps) {
  const total = MOCK_SAMPLES.length;
  const pending = MOCK_SAMPLES.filter(s => ["collected", "sealed", "registered", "transferred"].includes(s.status)).length;
  const positive = MOCK_SAMPLES.filter(s => s.fieldResult === "presumptive_positive" || s.labStatus === "confirmed_positive").length;
  const labPending = MOCK_SAMPLES.filter(s => ["awaiting_lab", "received", "under_analysis"].includes(s.labStatus)).length;

  const stats = [
    { label: "Total Tests", value: total, icon: FlaskConical, color: "bg-blue-50 text-blue-600", border: "border-blue-100" },
    { label: "Tests Pending", value: pending, icon: Clock, color: "bg-amber-50 text-amber-600", border: "border-amber-100" },
    { label: "Positive / Pres. Positive", value: positive, icon: AlertTriangle, color: "bg-red-50 text-red-600", border: "border-red-100" },
    { label: "Awaiting Lab Confirmation", value: labPending, icon: Microscope, color: "bg-violet-50 text-violet-600", border: "border-violet-100" },
  ];

  const quickActions = [
    { label: "New Field Test", icon: PlusCircle, view: "new_test" as ViewName, color: "bg-[#1B3A6B] text-white hover:bg-[#162f58]" },
    { label: "Scan QR Code", icon: QrCode, view: "qr_scanner" as ViewName, color: "bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200" },
    { label: "View Samples", icon: FlaskConical, view: "samples" as ViewName, color: "bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200" },
    { label: "Upload Evidence", icon: FileStack, view: "evidence" as ViewName, color: "bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200" },
    { label: "View Reports", icon: BarChart3, view: "reports" as ViewName, color: "bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200" },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl">
      {/* Welcome */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-[--foreground]">Good morning, {user.name.split(" ")[0]}</h1>
          <p className="text-sm text-[--muted-foreground]">Here is today&apos;s overview — {new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p>
        </div>
        <button
          onClick={() => onNavigate("new_test")}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#1B3A6B] text-white rounded-lg text-sm font-semibold hover:bg-[#162f58] transition-colors"
        >
          <PlusCircle size={16} />
          Start New Field Test
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map(stat => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className={`bg-white rounded-xl p-4 border ${stat.border} shadow-sm`}>
              <div className={`inline-flex p-2 rounded-lg ${stat.color} mb-3`}>
                <Icon size={18} />
              </div>
              <div className="text-2xl font-bold text-[--foreground]">{stat.value}</div>
              <div className="text-xs text-[--muted-foreground] mt-0.5 leading-tight">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {/* Charts + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Tests over time */}
        <div className="lg:col-span-2 bg-white rounded-xl p-5 border border-[--border] shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} className="text-blue-600" />
            <span className="text-sm font-semibold text-[--foreground]">Tests This Week</span>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={CHART_TESTS_OVER_TIME}>
              <defs>
                <linearGradient id="testGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={24} />
              <Tooltip
                contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }}
                itemStyle={{ color: "#2563EB" }}
              />
              <Area type="monotone" dataKey="tests" stroke="#2563EB" strokeWidth={2} fill="url(#testGrad)" dot={{ fill: "#2563EB", r: 3 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Result distribution */}
        <div className="bg-white rounded-xl p-5 border border-[--border] shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-4">Result Distribution</div>
          <ResponsiveContainer width="100%" height={130}>
            <PieChart>
              <Pie data={CHART_RESULT_DISTRIBUTION} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" paddingAngle={3}>
                {CHART_RESULT_DISTRIBUTION.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-x-2 gap-y-1 mt-2">
            {CHART_RESULT_DISTRIBUTION.map(d => (
              <div key={d.name} className="flex items-center gap-1.5 text-xs text-[--muted-foreground]">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: d.color }} />
                <span>{d.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions + Recent activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-5 border border-[--border] shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-3">Quick Actions</div>
          <div className="space-y-2">
            {quickActions.map(action => {
              const Icon = action.icon;
              return (
                <button
                  key={action.label}
                  onClick={() => onNavigate(action.view)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${action.color}`}
                >
                  <Icon size={16} />
                  {action.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-2 bg-white rounded-xl p-5 border border-[--border] shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="text-sm font-semibold text-[--foreground]">Recent Testing Activity</div>
            <button onClick={() => onNavigate("samples")} className="text-xs text-blue-600 hover:underline">View all</button>
          </div>
          <div className="space-y-2">
            {MOCK_SAMPLES.slice().reverse().map(sample => (
              <div
                key={sample.id}
                className="flex flex-wrap items-center gap-2 px-3 py-2.5 bg-[--muted] rounded-lg text-sm hover:bg-slate-100 cursor-pointer transition-colors"
                onClick={() => onNavigate("samples")}
              >
                <span className="font-mono text-xs font-semibold text-[--primary] w-28">{sample.id}</span>
                <span className="text-[--muted-foreground] text-xs flex-1 min-w-0 truncate">{sample.targetSubstance}</span>
                <FieldResultBadge result={sample.fieldResult} />
                <LabStatusBadge status={sample.labStatus} />
                <span className="text-[--muted-foreground] text-xs ml-auto whitespace-nowrap">{sample.collectionDate}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
