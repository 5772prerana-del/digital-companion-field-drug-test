import { useState } from "react";
import { CheckCircle2, Clock, Package, Truck, FlaskConical, FileText, ShieldCheck } from "lucide-react";
import { MOCK_CUSTODY_EVENTS } from "../data/mockData";
import type { Sample } from "../types";

const EVENT_ICONS: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  collection: Package,
  sealed: ShieldCheck,
  registered: Clock,
  transferred: Truck,
  lab_received: FlaskConical,
  lab_testing: FlaskConical,
  report_generated: FileText,
};

const EVENT_LABELS: Record<string, string> = {
  collection: "Sample Collected",
  sealed: "Sample Sealed",
  registered: "Sample Registered",
  transferred: "Sample Transferred",
  lab_received: "Received by Laboratory",
  lab_testing: "Laboratory Testing",
  report_generated: "Report Generated",
};

interface CoCProps {
  samples: Sample[];
}

export default function ChainOfCustody({ samples }: CoCProps) {
  const [selectedId, setSelectedId] = useState(samples[0]?.id || "DT-2026-001");

  const events = MOCK_CUSTODY_EVENTS.filter(e => e.sampleId === selectedId);
  const sample = samples.find(s => s.id === selectedId);

  return (
    <div className="p-4 md:p-6 max-w-4xl">
      {/* Sample selector */}
      <div className="bg-white rounded-xl border border-[--border] shadow-sm p-4 mb-5">
        <label className="block text-sm font-medium text-[--foreground] mb-2">Select Sample</label>
        <div className="flex flex-wrap gap-2">
          {samples.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedId(s.id)}
              className={`px-4 py-2 rounded-lg text-sm font-mono font-semibold transition-colors border ${
                selectedId === s.id
                  ? "bg-[#1B3A6B] text-white border-[#1B3A6B]"
                  : "bg-white text-[--primary] border-[--border] hover:bg-blue-50"
              }`}
            >
              {s.id}
            </button>
          ))}
        </div>
      </div>

      {sample && (
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="bg-white rounded-xl border border-[--border] p-3 text-sm">
            <div className="text-xs text-[--muted-foreground]">Sample ID</div>
            <div className="font-mono font-bold text-[--primary] mt-0.5">{sample.id}</div>
          </div>
          <div className="bg-white rounded-xl border border-[--border] p-3 text-sm">
            <div className="text-xs text-[--muted-foreground]">Case ID</div>
            <div className="font-mono font-semibold mt-0.5">{sample.caseId}</div>
          </div>
          <div className="bg-white rounded-xl border border-[--border] p-3 text-sm">
            <div className="text-xs text-[--muted-foreground]">CoC Status</div>
            <div className={`font-semibold mt-0.5 ${sample.cocStatus === "complete" ? "text-emerald-600" : "text-amber-600"}`}>
              {sample.cocStatus === "complete" ? "Complete" : "Partial"}
            </div>
          </div>
        </div>
      )}

      {/* Timeline */}
      <div className="bg-white rounded-xl border border-[--border] shadow-sm p-6">
        <h3 className="text-sm font-semibold text-[--foreground] mb-5">Custody Timeline</h3>
        {events.length === 0 ? (
          <div className="text-center py-8 text-sm text-[--muted-foreground]">No custody events recorded for this sample.</div>
        ) : (
          <div className="relative">
            <div className="absolute left-[22px] top-8 bottom-4 w-px bg-[--border]" />
            <div className="space-y-0">
              {events.map((event, i) => {
                const Icon = EVENT_ICONS[event.eventType] || Package;
                const isLast = i === events.length - 1;
                const ts = new Date(event.timestamp);
                return (
                  <div key={event.id} className="flex gap-4 relative">
                    <div className={`relative z-10 flex-shrink-0 w-11 h-11 rounded-full flex items-center justify-center mt-1 ${
                      event.signed ? "bg-emerald-100 text-emerald-600" : "bg-gray-100 text-gray-400"
                    }`}>
                      <Icon size={18} />
                    </div>
                    <div className={`flex-1 ${!isLast ? "pb-6" : ""}`}>
                      <div className="bg-[--muted] rounded-lg p-4">
                        <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                          <div>
                            <div className="text-sm font-semibold text-[--foreground]">{EVENT_LABELS[event.eventType] || event.eventType}</div>
                            <div className="text-xs text-[--muted-foreground] mt-0.5">
                              {ts.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })} · {ts.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
                            </div>
                          </div>
                          {event.signed ? (
                            <span className="flex items-center gap-1 text-xs text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                              <CheckCircle2 size={11} />Signed
                            </span>
                          ) : (
                            <span className="text-xs text-gray-400 bg-gray-50 border border-gray-200 px-2 py-0.5 rounded-full">Unsigned</span>
                          )}
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-[--muted-foreground]">
                          <div><span className="font-medium text-[--foreground]">Person</span><br />{event.personName}</div>
                          <div><span className="font-medium text-[--foreground]">Role</span><br />{event.personRole}</div>
                          <div><span className="font-medium text-[--foreground]">Location</span><br />{event.location}</div>
                          <div className="sm:col-span-2"><span className="font-medium text-[--foreground]">Action</span><br />{event.action}</div>
                          <div><span className="font-medium text-[--foreground]">Signature</span><br /><span className="font-mono">{event.signature}</span></div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
