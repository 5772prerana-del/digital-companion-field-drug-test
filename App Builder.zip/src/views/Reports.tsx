import { BarChart3, Download, Eye, FileText, Shield, FlaskConical, ClipboardList } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from "recharts";
import { MOCK_SAMPLES, CHART_TESTS_OVER_TIME } from "../data/mockData";
import { FieldResultBadge, LabStatusBadge } from "../components/ui/Badge";

const REPORT_TYPES = [
  { id: "summary", icon: BarChart3, label: "Test Summary Report", desc: "Overview of all tests, results, and sample statistics." },
  { id: "history", icon: ClipboardList, label: "Sample History Report", desc: "Full list of samples with collection and test details." },
  { id: "coc", icon: Shield, label: "Chain of Custody Report", desc: "Complete custody timeline for all registered samples." },
  { id: "lab", icon: FlaskConical, label: "Laboratory Confirmation Report", desc: "Lab results and confirmation status for all samples." },
];

export default function Reports() {
  const resultCounts = [
    { name: "Negative", value: MOCK_SAMPLES.filter(s => s.fieldResult === "negative").length, color: "#059669" },
    { name: "Pres. Positive", value: MOCK_SAMPLES.filter(s => s.fieldResult === "presumptive_positive").length, color: "#D97706" },
    { name: "Invalid", value: MOCK_SAMPLES.filter(s => s.fieldResult === "invalid").length, color: "#9CA3AF" },
  ];

  return (
    <div className="p-4 md:p-6 max-w-6xl space-y-5">
      {/* Report types */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {REPORT_TYPES.map(r => {
          const Icon = r.icon;
          return (
            <div key={r.id} className="bg-white rounded-xl border border-[--border] p-5 flex items-start gap-4 shadow-sm">
              <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon size={20} className="text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-[--foreground]">{r.label}</div>
                <div className="text-xs text-[--muted-foreground] mt-0.5 mb-3">{r.desc}</div>
                <div className="flex gap-2">
                  <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[--muted] hover:bg-gray-100 rounded text-xs font-medium text-[--foreground] transition-colors">
                    <Eye size={12} />Preview
                  </button>
                  <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1B3A6B] hover:bg-[#162f58] rounded text-xs font-medium text-white transition-colors">
                    <Download size={12} />Download PDF
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-[--border] p-5 shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-4">Tests Over Time</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={CHART_TESTS_OVER_TIME} barSize={20}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={24} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
              <Bar dataKey="tests" fill="#2563EB" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-[--border] p-5 shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-4">Result Distribution</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={resultCounts} barSize={40}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={24} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {resultCounts.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Data table preview */}
      <div className="bg-white rounded-xl border border-[--border] shadow-sm overflow-hidden">
        <div className="px-5 py-3 border-b border-[--border] flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-[--foreground]">
            <FileText size={15} className="text-[--muted-foreground]" />
            Sample History Preview
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1B3A6B] text-white rounded text-xs font-medium hover:bg-[#162f58] transition-colors">
            <Download size={12} />Export CSV
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[--muted] border-b border-[--border]">
                {["Sample ID", "Case ID", "Type", "Date", "Field Result", "Lab Status"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-[--muted-foreground] uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {MOCK_SAMPLES.map(s => (
                <tr key={s.id} className="border-b border-[--border]">
                  <td className="px-4 py-3 font-mono font-semibold text-[--primary] text-xs whitespace-nowrap">{s.id}</td>
                  <td className="px-4 py-3 font-mono text-xs text-[--muted-foreground] whitespace-nowrap">{s.caseId}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{s.sampleType}</td>
                  <td className="px-4 py-3 text-[--muted-foreground] whitespace-nowrap">{s.collectionDate}</td>
                  <td className="px-4 py-3 whitespace-nowrap"><FieldResultBadge result={s.fieldResult} /></td>
                  <td className="px-4 py-3 whitespace-nowrap"><LabStatusBadge status={s.labStatus} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
