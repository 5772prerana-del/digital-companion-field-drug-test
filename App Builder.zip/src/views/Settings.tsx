import { Save, ShieldCheck } from "lucide-react";
import type { User } from "../types";

interface SettingsProps {
  user: User;
}

export default function Settings({ user }: SettingsProps) {
  const inputCls = "w-full px-3 py-2.5 border border-[--border] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white";
  const labelCls = "block text-sm font-medium text-[--foreground] mb-1.5";
  const roleLabels: Record<string, string> = { officer: "Field Officer", lab: "Lab Technician", admin: "Administrator" };

  return (
    <div className="p-4 md:p-6 max-w-2xl space-y-4">
      <div className="bg-white rounded-xl border border-[--border] shadow-sm">
        <div className="px-6 py-4 border-b border-[--border]">
          <h3 className="text-sm font-semibold text-[--foreground]">Account Information</h3>
          <p className="text-xs text-[--muted-foreground] mt-0.5">Read-only in prototype mode</p>
        </div>
        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div><label className={labelCls}>Full Name</label><input className={`${inputCls} bg-gray-50`} readOnly value={user.name} /></div>
          <div><label className={labelCls}>Officer / Lab ID</label><input className={`${inputCls} bg-gray-50 font-mono`} readOnly value={user.id} /></div>
          <div><label className={labelCls}>Badge Number</label><input className={`${inputCls} bg-gray-50 font-mono`} readOnly value={user.badge} /></div>
          <div><label className={labelCls}>Role</label><input className={`${inputCls} bg-gray-50`} readOnly value={roleLabels[user.role]} /></div>
          <div className="sm:col-span-2"><label className={labelCls}>Unit / Division</label><input className={`${inputCls} bg-gray-50`} readOnly value={user.unit} /></div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-[--border] shadow-sm">
        <div className="px-6 py-4 border-b border-[--border]">
          <h3 className="text-sm font-semibold text-[--foreground]">Preferences</h3>
        </div>
        <div className="p-6 space-y-4">
          {[
            { label: "Email notifications for lab results", defaultChecked: true },
            { label: "Email notifications for chain-of-custody updates", defaultChecked: true },
            { label: "SMS alerts for presumptive positive results", defaultChecked: false },
            { label: "Auto-save drafts to local storage", defaultChecked: true },
          ].map(pref => (
            <label key={pref.label} className="flex items-center justify-between cursor-pointer">
              <span className="text-sm text-[--foreground]">{pref.label}</span>
              <input type="checkbox" defaultChecked={pref.defaultChecked} className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            </label>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-[--border] shadow-sm">
        <div className="px-6 py-4 border-b border-[--border]">
          <h3 className="text-sm font-semibold text-[--foreground]">Security</h3>
        </div>
        <div className="p-6 space-y-3">
          <div className="flex items-start gap-3 p-4 bg-[--muted] rounded-lg">
            <ShieldCheck size={18} className="text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-[--muted-foreground]">
              Password changes are managed through the Identity Management System. Contact your system administrator.
            </div>
          </div>
          <div>
            <label className={labelCls}>Session Timeout</label>
            <select className={inputCls}>
              <option>30 minutes</option>
              <option>1 hour</option>
              <option>4 hours</option>
              <option>8 hours (shift)</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button className="flex items-center gap-2 px-6 py-2.5 bg-[#1B3A6B] text-white rounded-lg text-sm font-semibold hover:bg-[#162f58] transition-colors">
          <Save size={15} />Save Preferences
        </button>
      </div>

      <div className="text-center text-xs text-[--muted-foreground] p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
        <strong>Prototype Notice:</strong> This application uses demo data only. No real enforcement actions should be taken based on this system.
      </div>
    </div>
  );
}
