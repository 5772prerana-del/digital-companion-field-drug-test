import { useState } from "react";
import { Upload, Image, FileText, CheckCircle2, Clock, Search } from "lucide-react";
import type { EvidenceFile } from "../types";

interface EvidenceProps {
  evidence: EvidenceFile[];
}

const FILE_ICONS: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  image: Image,
  document: FileText,
  video: FileText,
};

const COLORS: Record<string, string> = {
  image: "bg-blue-50 text-blue-600",
  document: "bg-amber-50 text-amber-600",
  video: "bg-purple-50 text-purple-600",
};

export default function Evidence({ evidence }: EvidenceProps) {
  const [search, setSearch] = useState("");
  const [dragOver, setDragOver] = useState(false);

  const filtered = evidence.filter(e =>
    e.fileName.toLowerCase().includes(search.toLowerCase()) ||
    e.sampleId.toLowerCase().includes(search.toLowerCase()) ||
    e.officerName.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 md:p-6 max-w-5xl">
      {/* Upload zone */}
      <div
        className={`bg-white rounded-xl border-2 border-dashed p-8 text-center mb-5 transition-colors ${
          dragOver ? "border-blue-400 bg-blue-50/50" : "border-[--border] hover:border-blue-300 hover:bg-blue-50/30"
        }`}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={e => { e.preventDefault(); setDragOver(false); }}
      >
        <Upload size={28} className="text-gray-400 mx-auto mb-3" />
        <p className="text-sm font-medium text-[--foreground] mb-1">Upload Evidence Files</p>
        <p className="text-xs text-[--muted-foreground] mb-3">Test strip photos, sample containers, scene documentation</p>
        <button className="px-5 py-2 bg-[#1B3A6B] text-white rounded-lg text-sm font-semibold hover:bg-[#162f58] transition-colors">
          Browse Files
        </button>
        <p className="text-xs text-gray-400 mt-2">PNG, JPG, PDF, MP4 · Max 50MB per file</p>
      </div>

      {/* File list */}
      <div className="bg-white rounded-xl border border-[--border] shadow-sm">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[--border]">
          <div className="relative flex-1 max-w-xs">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              className="w-full pl-9 pr-4 py-2 border border-[--border] rounded-lg text-sm bg-[--muted] focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Search evidence..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <span className="text-xs text-[--muted-foreground] ml-auto">{filtered.length} file{filtered.length !== 1 ? "s" : ""}</span>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-12 text-sm text-[--muted-foreground]">No evidence files found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-[--muted] border-b border-[--border]">
                  {["File", "Sample ID", "Officer", "Uploaded", "Type", "Size", "Verified"].map(h => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-[--muted-foreground] uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(file => {
                  const Icon = FILE_ICONS[file.fileType] || FileText;
                  return (
                    <tr key={file.id} className="border-b border-[--border] hover:bg-blue-50/30 transition-colors cursor-pointer">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${COLORS[file.fileType]}`}>
                            <Icon size={15} />
                          </div>
                          <span className="text-sm text-[--foreground] font-medium">{file.fileName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-[--primary] font-semibold whitespace-nowrap">{file.sampleId}</td>
                      <td className="px-4 py-3 text-[--muted-foreground] whitespace-nowrap">{file.officerName}</td>
                      <td className="px-4 py-3 text-[--muted-foreground] whitespace-nowrap">{file.uploadDate} {file.uploadTime}</td>
                      <td className="px-4 py-3 capitalize">{file.fileType}</td>
                      <td className="px-4 py-3 text-[--muted-foreground] font-mono text-xs">{file.size}</td>
                      <td className="px-4 py-3">
                        {file.verified ? (
                          <span className="flex items-center gap-1 text-xs text-emerald-600">
                            <CheckCircle2 size={13} />Verified
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-xs text-amber-500">
                            <Clock size={13} />Pending
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
