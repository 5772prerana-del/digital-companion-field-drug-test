import { Users, FlaskConical, CheckCircle2, Clock, AlertTriangle, BarChart2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell, Legend } from "recharts";
import { MOCK_SAMPLES, CHART_TESTS_OVER_TIME, CHART_RESULT_DISTRIBUTION, CHART_LAB_STATUS } from "../data/mockData";

export default function AdminDashboard() {
  const stats = [
    { label: "Total Officers", value: 12, icon: Users, color: "text-blue-600 bg-blue-50", border: "border-blue-100" },
    { label: "Total Samples", value: MOCK_SAMPLES.length, icon: FlaskConical, color: "text-violet-600 bg-violet-50", border: "border-violet-100" },
    { label: "Tests Completed", value: MOCK_SAMPLES.filter(s => !["collected", "sealed", "registered"].includes(s.status)).length, icon: CheckCircle2, color: "text-emerald-600 bg-emerald-50", border: "border-emerald-100" },
    { label: "Pending Lab Confirmations", value: MOCK_SAMPLES.filter(s => ["awaiting_lab", "received", "under_analysis"].includes(s.labStatus)).length, icon: Clock, color: "text-amber-600 bg-amber-50", border: "border-amber-100" },
    { label: "Invalid Tests", value: MOCK_SAMPLES.filter(s => s.fieldResult === "invalid").length, icon: AlertTriangle, color: "text-red-600 bg-red-50", border: "border-red-100" },
    { label: "Active Cases", value: 8, icon: BarChart2, color: "text-indigo-600 bg-indigo-50", border: "border-indigo-100" },
  ];

  return (
    <div className="p-4 md:p-6 space-y-5 max-w-7xl">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {stats.map(s => {
          const Icon = s.icon;
          return (
            <div key={s.label} className={`bg-white rounded-xl p-4 border ${s.border} shadow-sm`}>
              <div className={`inline-flex p-2 rounded-lg ${s.color} mb-2`}><Icon size={16} /></div>
              <div className="text-2xl font-bold text-[--foreground]">{s.value}</div>
              <div className="text-xs text-[--muted-foreground] mt-0.5 leading-tight">{s.label}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {/* Tests over time */}
        <div className="xl:col-span-2 bg-white rounded-xl border border-[--border] p-5 shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-4">Tests Over Time (Last 8 Days)</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={CHART_TESTS_OVER_TIME} barSize={22}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={24} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E2E8F0" }} />
              <Bar dataKey="tests" fill="#1B3A6B" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Result distribution */}
        <div className="bg-white rounded-xl border border-[--border] p-5 shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-4">Result Distribution</div>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={CHART_RESULT_DISTRIBUTION} cx="50%" cy="50%" outerRadius={65} dataKey="value" paddingAngle={3}>
                {CHART_RESULT_DISTRIBUTION.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Legend iconType="circle" iconSize={8} formatter={v => <span style={{ fontSize: 11, color: "#64748B" }}>{v}</span>} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Lab status */}
        <div className="xl:col-span-2 bg-white rounded-xl border border-[--border] p-5 shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-4">Sample Status Distribution</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={CHART_LAB_STATUS} barSize={28} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
              <XAxis type="number" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} width={90} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {CHART_LAB_STATUS.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Quick stats card */}
        <div className="bg-white rounded-xl border border-[--border] p-5 shadow-sm">
          <div className="text-sm font-semibold text-[--foreground] mb-4">System Health</div>
          <div className="space-y-3">
            {[
              { label: "Sync Status", value: "Online", dot: "bg-emerald-400" },
              { label: "Last Backup", value: "Today 06:00", dot: "bg-emerald-400" },
              { label: "Active Sessions", value: "3", dot: "bg-blue-400" },
              { label: "Storage Used", value: "2.4 GB / 50 GB", dot: "bg-amber-400" },
              { label: "Lab API Status", value: "Connected", dot: "bg-emerald-400" },
            ].map(item => (
              <div key={item.label} className="flex items-center justify-between text-sm">
                <span className="text-[--muted-foreground] text-xs">{item.label}</span>
                <div className="flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${item.dot}`} />
                  <span className="text-xs font-medium text-[--foreground]">{item.value}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
