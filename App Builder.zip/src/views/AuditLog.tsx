import { useState } from "react";
import { Search, CheckCircle2, XCircle, Shield } from "lucide-react";
import { MOCK_AUDIT } from "../data/mockData";

export default function AuditLog() {
  const [search, setSearch] = useState("");
  const [filterAction, setFilterAction] = useState("all");

  const actions = ["all", ...Array.from(new Set(MOCK_AUDIT.map(a => a.action)))];

  const filtered = MOCK_AUDIT.filter(a => {
    const matchSearch = a.userName.toLowerCase().includes(search.toLowerCase()) ||
      a.resource.toLowerCase().includes(search.toLowerCase()) ||
      a.resourceId.toLowerCase().includes(search.toLowerCase()) ||
      a.details.toLowerCase().includes(search.toLowerCase());
    const matchAction = filterAction === "all" || a.action === filterAction;
    return matchSearch && matchAction;
  });

  const formatTs = (ts: string) => {
    const d = new Date(ts);
    return d.toLocaleString("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  };

  const actionColors: Record<string, string> = {
    LOGIN: "bg-blue-100 text-blue-700",
    CREATE: "bg-emerald-100 text-emerald-700",
    UPDATE: "bg-amber-100 text-amber-700",
    VIEW: "bg-slate-100 text-slate-600",
    UPLOAD: "bg-violet-100 text-violet-700",
    DELETE: "bg-red-100 text-red-700",
  };

  return (
    <div className="p-4 md:p-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            className="w-full pl-9 pr-4 py-2.5 border border-[--border] rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Search user, resource, details..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select className="px-3 py-2.5 border border-[--border] rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={filterAction} onChange={e => setFilterAction(e.target.value)}>
          {actions.map(a => <option key={a} value={a}>{a === "all" ? "All Actions" : a}</option>)}
        </select>
      </div>

      <div className="bg-white rounded-xl border border-[--border] shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-[--border] flex items-center gap-2">
          <Shield size={15} className="text-[--muted-foreground]" />
          <span className="text-sm font-semibold text-[--foreground]">Audit Trail</span>
          <span className="text-xs text-[--muted-foreground] ml-1">({filtered.length} entries)</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[--muted] border-b border-[--border]">
                {["Timestamp", "User", "Role", "Action", "Resource", "Details", "IP Address", "Result"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-[--muted-foreground] uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-10 text-[--muted-foreground] text-sm">No entries match.</td></tr>
              ) : filtered.map(entry => (
                <tr key={entry.id} className={`border-b border-[--border] text-sm ${entry.result === "failure" ? "bg-red-50/50" : ""}`}>
                  <td className="px-4 py-3 font-mono text-xs text-[--muted-foreground] whitespace-nowrap">{formatTs(entry.timestamp)}</td>
                  <td className="px-4 py-3 whitespace-nowrap font-medium">{entry.userName}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-[--muted-foreground] text-xs">{entry.userRole}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${actionColors[entry.action] || "bg-gray-100 text-gray-600"}`}>
                      {entry.action}
                    </span>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-[--muted-foreground]">{entry.resource}</td>
                  <td className="px-4 py-3 text-xs text-[--muted-foreground] max-w-xs">{entry.details}</td>
                  <td className="px-4 py-3 font-mono text-xs text-[--muted-foreground] whitespace-nowrap">{entry.ipAddress}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {entry.result === "success" ? (
                      <span className="flex items-center gap-1 text-xs text-emerald-600"><CheckCircle2 size={13} />OK</span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs text-red-600"><XCircle size={13} />Failed</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
