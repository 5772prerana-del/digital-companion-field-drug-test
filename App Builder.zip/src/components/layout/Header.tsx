import { Menu, Wifi, WifiOff, RefreshCw } from "lucide-react";
import type { ViewName } from "../../App";

const VIEW_LABELS: Record<ViewName, string> = {
  dashboard: "Dashboard",
  new_test: "New Field Test",
  samples: "Sample Management",
  qr_scanner: "QR Scanner",
  chain_of_custody: "Chain of Custody",
  evidence: "Evidence Management",
  laboratory: "Laboratory",
  reports: "Reports",
  notifications: "Notifications",
  audit_log: "Audit Log",
  admin_dashboard: "Admin Panel",
  settings: "Settings",
};

interface HeaderProps {
  currentView: ViewName;
  onMenuToggle: () => void;
  synced: boolean;
}

export default function Header({ currentView, onMenuToggle, synced }: HeaderProps) {
  const now = new Date();
  const timeStr = now.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  const dateStr = now.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric" });

  return (
    <header className="h-14 bg-white border-b border-[--border] flex items-center px-4 gap-3 sticky top-0 z-20">
      <button
        className="lg:hidden p-1.5 rounded-md hover:bg-gray-100 transition-colors"
        onClick={onMenuToggle}
      >
        <Menu size={20} className="text-gray-600" />
      </button>

      <div className="font-semibold text-[--foreground] text-base">{VIEW_LABELS[currentView]}</div>

      <div className="flex-1" />

      <div className="flex items-center gap-3 text-sm text-[--muted-foreground]">
        <div className="hidden sm:flex items-center gap-1.5">
          {synced ? (
            <><Wifi size={14} className="text-emerald-500" /><span className="text-xs text-emerald-600 font-medium">Synced</span></>
          ) : (
            <><WifiOff size={14} className="text-amber-500" /><span className="text-xs text-amber-600 font-medium">Saved Locally</span></>
          )}
        </div>
        <div className="hidden md:flex items-center gap-1 text-xs">
          <RefreshCw size={12} className="text-gray-400" />
          <span>{timeStr} · {dateStr}</span>
        </div>
      </div>
    </header>
  );
}
