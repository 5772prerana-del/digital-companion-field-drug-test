import {
  LayoutDashboard, FlaskConical, QrCode, Link2, FileStack,
  ShieldCheck, BarChart3, Bell, ClipboardList, Settings,
  LogOut, ChevronRight, Beaker, UserCog, PlusCircle,
} from "lucide-react";
import type { User } from "../../types";
import type { ViewName } from "../../App";

interface NavItem {
  id: ViewName;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  roles: string[];
}

const NAV_ITEMS: NavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["officer", "admin"] },
  { id: "new_test", label: "New Field Test", icon: PlusCircle, roles: ["officer"] },
  { id: "samples", label: "Samples", icon: FlaskConical, roles: ["officer", "lab", "admin"] },
  { id: "qr_scanner", label: "QR Scanner", icon: QrCode, roles: ["officer", "lab"] },
  { id: "chain_of_custody", label: "Chain of Custody", icon: Link2, roles: ["officer", "lab", "admin"] },
  { id: "evidence", label: "Evidence", icon: FileStack, roles: ["officer", "admin"] },
  { id: "laboratory", label: "Laboratory", icon: Beaker, roles: ["lab", "admin"] },
  { id: "reports", label: "Reports", icon: BarChart3, roles: ["officer", "lab", "admin"] },
  { id: "notifications", label: "Notifications", icon: Bell, roles: ["officer", "lab", "admin"] },
  { id: "audit_log", label: "Audit Log", icon: ClipboardList, roles: ["admin"] },
  { id: "admin_dashboard", label: "Admin Panel", icon: UserCog, roles: ["admin"] },
  { id: "settings", label: "Settings", icon: Settings, roles: ["officer", "lab", "admin"] },
];

interface SidebarProps {
  user: User;
  currentView: ViewName;
  onNavigate: (view: ViewName) => void;
  onLogout: () => void;
  notifCount: number;
  mobileOpen: boolean;
  onMobileClose: () => void;
}

export default function Sidebar({ user, currentView, onNavigate, onLogout, notifCount, mobileOpen, onMobileClose }: SidebarProps) {
  const visibleItems = NAV_ITEMS.filter(item => item.roles.includes(user.role));

  const roleLabel: Record<string, string> = { officer: "Field Officer", lab: "Lab Technician", admin: "Administrator" };
  const roleColor: Record<string, string> = { officer: "bg-blue-600", lab: "bg-emerald-600", admin: "bg-violet-600" };

  const handleNav = (view: ViewName) => {
    onNavigate(view);
    onMobileClose();
  };

  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={onMobileClose}
        />
      )}

      <aside
        className={`
          fixed top-0 left-0 h-full z-40 flex flex-col
          w-64 bg-[#0F2347] text-white
          transform transition-transform duration-200 ease-in-out
          lg:translate-x-0 lg:static lg:z-auto
          ${mobileOpen ? "translate-x-0" : "-translate-x-full"}
        `}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-white/10">
          <div className="w-9 h-9 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
            <ShieldCheck size={20} />
          </div>
          <div>
            <div className="font-bold text-sm leading-tight">DrugTest</div>
            <div className="text-xs text-blue-300 font-medium">Companion</div>
          </div>
          <span className="ml-auto text-[10px] bg-yellow-400/20 text-yellow-300 border border-yellow-400/30 px-1.5 py-0.5 rounded font-mono font-medium">DEMO</span>
        </div>

        {/* User info */}
        <div className="px-4 py-3 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-full ${roleColor[user.role]} flex items-center justify-center text-xs font-bold`}>
              {user.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate">{user.name}</div>
              <div className="text-xs text-blue-300 truncate">{roleLabel[user.role]} · {user.badge}</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {visibleItems.map(item => {
            const Icon = item.icon;
            const active = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`
                  w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium mb-0.5
                  transition-colors duration-150 text-left
                  ${active
                    ? "bg-blue-600 text-white"
                    : "text-blue-100/80 hover:bg-white/10 hover:text-white"
                  }
                `}
              >
                <Icon size={17} className="flex-shrink-0" />
                <span className="flex-1">{item.label}</span>
                {item.id === "notifications" && notifCount > 0 && (
                  <span className="bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {notifCount}
                  </span>
                )}
                {active && <ChevronRight size={14} className="opacity-60" />}
              </button>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="p-3 border-t border-white/10">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-blue-200/70 hover:bg-white/10 hover:text-white transition-colors"
          >
            <LogOut size={16} />
            Sign Out
          </button>
        </div>
      </aside>
    </>
  );
}
