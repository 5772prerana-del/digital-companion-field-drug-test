import type { FieldResult, LabStatus, SampleStatus } from "../../types";

const FIELD_RESULT_STYLES: Record<FieldResult, string> = {
  negative: "bg-emerald-100 text-emerald-700 border-emerald-200",
  presumptive_positive: "bg-amber-100 text-amber-700 border-amber-200",
  invalid: "bg-gray-100 text-gray-600 border-gray-200",
  pending: "bg-blue-50 text-blue-600 border-blue-200",
};

const FIELD_RESULT_LABELS: Record<FieldResult, string> = {
  negative: "Negative",
  presumptive_positive: "Pres. Positive",
  invalid: "Invalid",
  pending: "Pending",
};

const LAB_STATUS_STYLES: Record<LabStatus, string> = {
  awaiting_lab: "bg-slate-100 text-slate-600 border-slate-200",
  received: "bg-blue-100 text-blue-700 border-blue-200",
  under_analysis: "bg-amber-100 text-amber-700 border-amber-200",
  confirmed_negative: "bg-emerald-100 text-emerald-700 border-emerald-200",
  confirmed_positive: "bg-red-100 text-red-700 border-red-200",
  invalid_retest: "bg-orange-100 text-orange-700 border-orange-200",
};

const LAB_STATUS_LABELS: Record<LabStatus, string> = {
  awaiting_lab: "Awaiting Lab",
  received: "Received",
  under_analysis: "Under Analysis",
  confirmed_negative: "Confirmed Negative",
  confirmed_positive: "Confirmed Positive",
  invalid_retest: "Invalid / Retest",
};

export function FieldResultBadge({ result }: { result: FieldResult }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${FIELD_RESULT_STYLES[result]}`}>
      {FIELD_RESULT_LABELS[result]}
    </span>
  );
}

export function LabStatusBadge({ status }: { status: LabStatus }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${LAB_STATUS_STYLES[status]}`}>
      {LAB_STATUS_LABELS[status]}
    </span>
  );
}

export function CoCBadge({ status }: { status: "complete" | "partial" | "pending" }) {
  const styles = {
    complete: "bg-emerald-100 text-emerald-700 border-emerald-200",
    partial: "bg-amber-100 text-amber-700 border-amber-200",
    pending: "bg-slate-100 text-slate-600 border-slate-200",
  };
  const labels = { complete: "Complete", partial: "Partial", pending: "Pending" };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${styles[status]}`}>
      {labels[status]}
    </span>
  );
}
